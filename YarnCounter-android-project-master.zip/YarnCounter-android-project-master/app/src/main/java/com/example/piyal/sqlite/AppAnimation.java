package com.example.piyal.sqlite;

/**
 * Created by piyal on 12/14/2017.
 */
public class AppAnimation {

}
